# Reveil_berry
## Projet système exploitation P18M groupe 1 (Arnaud/Vincent/Frederic/Claude)

>Fichier en cours de construction.
>Il sera transférer à terme sous gitpages.

Notre réveil aura les fonctionnalités standard que l'on peut trouver sur un téléphone:
* Réveil 
* Chronomètre
  * Possibilité de stocker jusqu'à 3 temps intermédiaires
* Minuteur
* Horloge

Mais il sera aussi connecté à un **RaspBerry Pi 3.0 modèle B** pour être un peu plus festif que un réveil standard.

Le fichier d'initialisation n'est pas encore finalisé, il n'est donc pas disponible.

Plus de détails sur : https://claudio4813.github.io/Reveil_berry/
